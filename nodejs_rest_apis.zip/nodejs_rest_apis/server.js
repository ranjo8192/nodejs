var express = require('express');
var fs = require('fs');
var bodyparser = require('body-parser');
var pug = require('pug');
var app = express();
app.set('view engine','pug');

app.get('/', function(req, res){
	//res.writeHead(200, {'content-type':'text/html'});
	res.render('index',{title:'Press Submit Button',message:'Hello There'});
});
app.get('/listUsers', function(req,res){
	fs.readFile(__dirname + "/" + "users.json" , function(err, data){
		if(err) throw err;
		console.log(data);
		res.end(data);
	});
});

// Add User
var user = {
	"user4":{
		"name" : "Ranjeet",
		"password" : "password4",
		"profession" : "Developer",
		"id" : 4
	}
};

app.post('/addUser', function(req,res){
	// First read existing Users 
	fs.readFile(__dirname + "/" + "users.json",'utf8', function(err, data){
		if(err) throw err;
		data = JSON.parse(data);
		data["user4"] = user["user4"];
		console.log(data);
		res.end(JSON.stringify(data));
	});
});

// Show details using user Ids
app.get('/:id', function(req,res){
	// First read existing Users 
	fs.readFile(__dirname + "/" + "users.json",'utf8', function(err, data){
		if(err) throw err;
		var users = JSON.parse(data);
		var user = users["user" + req.params.id];
		console.log(user);
		res.end(JSON.stringify(user));
	});
});

// Delete data Ids
var id = 2;
app.delete('/deleteUser', function (req, res) {

   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       data = JSON.parse( data );
       delete data["user" + 2];
       
       console.log( data );
       res.end( JSON.stringify(data));
   });
})


var server = app.listen(8081, function(){
	var host = server.address().address;
	var port = server.address().port;
	console.log("Rest Api app is listening at http://%s:%s", host, port);
});
