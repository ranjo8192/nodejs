var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = "mongodb://localhost:27017/mydb";

mongoClient.connect(url,function(err,db){
	if(err){
		throw err;
	}
	var customers = [
					{name:"Ajeet",address:"Kanpur",mobile:4464646466},
					{name:"Sumit",address:"Jhkarkati",mobile:4464646466},
					{name:"Mayank",address:"kailash Colony",mobile:4464646466},
					{name:"Kallu",address:"Ki moi",mobile:4464646466},
					{name:"Millu",address:"Jhai Sai",mobile:4464646466},
					{name:"Shobit",address:"Pakku Nikku",mobile:4464646466},
					{name:"Shusheel",address:"Chunnu Munnu",mobile:4464646466},
					{name:"jhantu Singh",address:"AAte Jaate",mobile:4464646466},
					{name:"Gdaha Chand",address:"Baak Tu",mobile:4464646466}
	];

	db.collection("customers").insertMany(customers,function(err,response){
		if(err){
			throw err;
		}
		console.log("Number of document inserted :"+ response.insertedCount);
	});
});