var mongodb = require('mongodb');

var mongoClient = mongodb.MongoClient;
var url = "mongodb://localhost:27017/mydb";

mongoClient.connect(url,function(err,db){

	if(err){
		throw err;
	}
	var customer = {name:"Ranjeet",address:"Delhi",mobile:9643515389};
	db.collection("customers").insertOne(customer,function(err,res){
		if(err){
			throw err;
		}
		console.log("One documnet inserted: "+ res);
		db.close();
	});

});