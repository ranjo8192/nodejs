var http = require("http");

var responseWriter = function (request, response) {
	
	response.writeHead(200, {'Content-Type' : 'text/html'});
	response.end("<HTML> <Body> <b> Hello World.. <b>  welcome to nodejs !!!! </body></html>");
}

http.createServer(responseWriter).listen(1111);
console.log("server started : http://localhost:1111");
