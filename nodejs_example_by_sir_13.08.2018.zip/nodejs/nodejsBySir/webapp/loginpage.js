var http = require("http");

var responseWriter = function (request, response) {
	
	response.writeHead(200, {'Content-Type' : 'text/html'});
	
	var page = "<HTML><head> <title>Login Page </title></head> <body> <center> Enter Your Username <input type='text' name='username'>"
				+ " <br> Enter YPassword <input type='password' name='password'> "
				+ " <br> <input type='submit' name='login' value='Login'> "
				+ "</body></HTML>";
	
	
	
	response.end(page, function() {
		console.log("sending data to browser............")
	});
}

http.createServer(responseWriter).listen(2222);
console.log("server started");
