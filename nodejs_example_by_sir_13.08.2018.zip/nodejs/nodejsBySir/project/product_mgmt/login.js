var mysql = require('mysql');

var express = require('express');


var app = express();

app.use(express.static('public'));

app.get('/', function (req, res) {
   res.sendFile( __dirname + "/" + "login.html" );
})

app.get('/success', function (req, res) {
   res.sendFile( __dirname + "/" + "success.html" );
})

app.get('/login', function (req, res) {
   var userNameReq = req.query.UserName;
   var passwordReq = req.query.Password;
   
   var dbUserName = "";
   var dbPassword = "";
	
   var con = mysql.createConnection({
			host: "localhost",
			user: "root",
			password: "",
			database: "test"
		});
		
		
	  con.connect(function(err) {
	  if (err) 
		  throw err;
	  
	  console.log("Connected!");
	   var sql = "SELECT username, password FROM users";
	   
	   con.query(sql, function (err, result, fields) {
		if (err) 
			throw err;
		console.log("result.length...." + result.length);
		if (result.length == 0) {
			console.log("No records found....");
		}
		
		
		for(var i=0; i<result.length;i++) {
			dbUserName = result[i].username;
			dbPassword = result[i].password;
			console.log("result[i].username...." + dbUserName);
			console.log("result[i].password...." + dbPassword);
		}
		
		console.log("dbUserName...." + dbUserName);
		console.log("dbPassword...." + dbPassword);
		if((userNameReq == dbUserName) && (passwordReq == dbPassword)) {
			console.log("Login successful.........");
			res.redirect("/addproductform");
		}
		else {
			console.log("Login FAiled.........");
			res.redirect("/");
		}
	  });
});
   
    
	
})

/****************************** end of login code ************************************/

app.get('/addproductform', function (req, res) {
   res.sendFile( __dirname + "/" + "addproduct.html" );
})



var server = app.listen(8081, function () {
  console.log("Listening on http://127.0.0.1:8081/");
});