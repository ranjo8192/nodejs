var aa = require("./my_module")

console.log("Today date is " + aa.myDateTime())
console.log("Message :  " + aa.helloWorld())