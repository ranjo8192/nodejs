exports.myDateTime = function () {
    return Date();
};

exports.helloWorld = function () {
    return "This is hello world";
};