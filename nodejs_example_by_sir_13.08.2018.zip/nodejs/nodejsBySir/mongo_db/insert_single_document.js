var mongodb = require('mongodb');

var mongoClient = mongodb.MongoClient;
var url = "mongodb://localhost:27017/mydb";

mongoClient.connect(url, function(err, db) {
  if (err) 
  {
	  throw err;
  }
  
  var customer = {name:"Rakesh Kumar" , address: "B-222, Sector-12, NOIDA"};
  
  db.collection("customers").insertOne(customer, function(error, response) {
	 if (err) {
			throw err;
	 }
	 
	console.log("1 document inserted");
    db.close();
	 
	 
  });
  
  
});