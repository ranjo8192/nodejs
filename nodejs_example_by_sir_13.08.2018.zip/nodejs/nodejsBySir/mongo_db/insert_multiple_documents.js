var mongodb = require('mongodb');

var mongoClient = mongodb.MongoClient;
var url = "mongodb://localhost:27017/mydb";

mongoClient.connect(url, function(err, db) {
  if (err) 
  {
	  throw err;
  }
  
  var customers = [
     {name:"Rakesh Kumar" , address: "B-222, Sector-12, NOIDA"},
	 {name:"Amit Kumar" , address: "C-222, Sector-22, NOIDA"},
	 {name:"Kamesh Kumar" , address: "D-222, Sector-32, NOIDA"},
	 {name:"Deleep Kumar" , address: "E-222, Sector-42, NOIDA"}
  ];
  
  
		
  
  db.collection("customers").insertMany(customers, function(error, response) {
	 if (err) {
			throw err;
	 }
	 
	console.log("Number of documents inserted: " + response.insertedCount);
    db.close();
	 
	 
  });
  
  
});